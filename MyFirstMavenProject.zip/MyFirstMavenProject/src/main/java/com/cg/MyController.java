package com.cg;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class MyController {
@RequestMapping("/hello")

}
