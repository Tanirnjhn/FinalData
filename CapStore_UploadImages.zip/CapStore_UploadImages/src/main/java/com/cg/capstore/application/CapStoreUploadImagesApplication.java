package com.cg.capstore.application;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CapStoreUploadImagesApplication {

	public static void main(String[] args) {
		SpringApplication.run(CapStoreUploadImagesApplication.class, args);
	
		
	
	}

}
