package com.cg.bean;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableAutoConfiguration
@ComponentScan("com.cg")
public class Client {

	public static void main(String[] args) {
		/* using Spring Boot Application*/
//		ApplicationContext context=SpringApplication.run(Client.class, args);
		
		
		//this used for run the application without spring boot application
		ApplicationContext context=new AnnotationConfigApplicationContext(Client.class);
		Employee ep=(Employee)context.getBean("emp");
		System.out.println(ep);

	}

}
