package conferencePage;

import static org.junit.Assert.assertEquals;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import PageBean.ConferencePageBean;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefConferencePage {
private WebDriver driver;
private ConferencePageBean obj;
	@Given("^User is on Conference Registration page$")
	public void user_is_on_Conference_Registration_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver","D:\\Users\\TANAGRAW\\Desktop\\taneesha\\module 3\\chromedriver_win32\\chromedriver.exe");
	    driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		obj = new ConferencePageBean(driver);
		driver.get("file:///D:/Users/TANAGRAW/Desktop/taneesha/module%203/MPT_setB/ConferenceRegistartion.html#");
	}

	@Then("^check the title of the page$")
	public void check_the_title_of_the_page() throws Throwable {
		String title=driver.getTitle();
		if(title.contentEquals("Conference Registartion")) System.out.println("****** Title Matched");
		else System.out.println("****** Title NOT Matched");
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		driver.close();
	}

	@When("^user leaves first Name blank$")
	public void user_leaves_first_Name_blank() throws Throwable {
		obj.setPffname("");	
		Thread.sleep(1000);
	}

	@When("^clicks the button$")
	public void clicks_the_button() throws Throwable {
		obj.setPfbutton();
	}

	@Then("^display alert msg$")
	public void display_alert_msg() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
	    System.out.println("******" + alertMessage);
	    driver.close();
	}
	@When("^user leaves last Name blank and clicks the button$")
	public void user_leaves_last_Name_blank_and_clicks_the_button() throws Throwable {
		obj.setPffname("abc");
		Thread.sleep(1000);
	obj.setPflname("");
	Thread.sleep(1000);
	obj.setPfbutton();
	}
	


	@When("^user enters all data$")
	public void user_enters_all_data() throws Throwable {
		obj.setPffname("abc");	
		Thread.sleep(1000);
		obj.setPflname("qwer");	
		Thread.sleep(1000);
		obj.setPfmobile("7722005480");
		Thread.sleep(1000);
		obj.setPfpersons("5");	
		Thread.sleep(1000);
		obj.setPfbuild("buv & 100");
		Thread.sleep(1000);
		obj.setPfarea("mno");
		Thread.sleep(1000);
	    obj.setPfcity("Pune");
	    Thread.sleep(1000);
 	    obj.setPfstate("Maharashtra");
 	    Thread.sleep(1000);
 	   obj.setMemberStatus("member");
		Thread.sleep(1000);
		
	}

	@When("^user enters incorrect email format and clicks the button$")
	public void user_enters_incorrect_email_format_and_clicks_the_button() throws Throwable {
		obj.setPfemail("Capg1@.com");	
		Thread.sleep(1000);
		obj.setPfbutton();
	}

	@When("^user leaves MobileNo blank and clicks the button$")
	public void user_leaves_MobileNo_blank_and_clicks_the_button() throws Throwable {
		obj.setPffname("abc");
		Thread.sleep(1000);
		obj.setPflname("qwer");
		Thread.sleep(1000);
		obj.setPfemail("Capg1@gamil.com");
		Thread.sleep(1000);
		obj.setPfmobile("");
		Thread.sleep(1000);
		
		obj.setPfbutton();
	}

	@When("^user enters incorrect mobileNo format and clicks the button$")
	public void user_enters_incorrect_mobileNo_format_and_clicks_the_button(DataTable arg1) throws Throwable {
		obj.setPffname("abc");
		Thread.sleep(1000);
		obj.setPflname("qwer");
		Thread.sleep(1000);
		obj.setPfemail("Capg1@gamil.com");
		Thread.sleep(1000);
		
		List<String> objList = arg1.asList(String.class);
		//objhbpg.setPfmobile(objList);	Thread.sleep(1000);
		obj.setPfbutton();
		
		for(int i=0; i<objList.size(); i++) {
			if(Pattern.matches("^[7-9]{1}[0-9]{9}$", objList.get(i))) {
			System.out.println("***** Matched" + objList.get(i) + "*****");
			}
			else {
				System.out.println("***** NOT Matched" + objList.get(i) + "*****");
			}
		}
	}


@When("^user doesnot select number of people attending$")
public void user_doesnot_select_number_of_people_attending() throws Throwable {
	obj.setPffname("abc");
	Thread.sleep(1000);
	obj.setPflname("qwer");
	Thread.sleep(1000);
	obj.setPfemail("Capg1@gamil.com");
	Thread.sleep(1000);
	obj.setPfpersons("1");
	Thread.sleep(1000);
    obj.getPfbutton();
}

	

	@When("^user leaves Building name and Room No$")
	public void user_leaves_Building_name_and_Room_No() throws Throwable {
		obj.setPffname("abc");
		Thread.sleep(1000);
		obj.setPflname("qwer");
		Thread.sleep(1000);
		obj.setPfemail("Capg1@gamil.com");
		Thread.sleep(1000);
		obj.setPfmobile("7722005480");
		Thread.sleep(1000);
		obj.setPfpersons("3");
		Thread.sleep(2000);
		obj.setPfbuild("");
		Thread.sleep(1000);
		obj.setPfbutton();
	}

	@When("^user leaves Area name$")
	public void user_leaves_Area_name() throws Throwable {
		obj.setPffname("abc");	
		Thread.sleep(1000);
		obj.setPflname("qwer");	
		Thread.sleep(1000);
		obj.setPfemail("Capg1@gamil.com");
		Thread.sleep(1000);
		obj.setPfmobile("7722005480");	
		Thread.sleep(1000);
		obj.setPfpersons("3");	
		Thread.sleep(1000);
		obj.setPfbuild("buv & 100");
		Thread.sleep(1000);
		obj.setPfarea("");
		Thread.sleep(1000);
		obj.setPfbutton();
	}

	@When("^user doesnot select city$")
	public void user_doesnot_select_city() throws Throwable {
		obj.setPffname("abc");	
		Thread.sleep(1000);
		obj.setPflname("qwer");	
		Thread.sleep(1000);
		obj.setPfemail("Capg1@gamil.com");
		Thread.sleep(1000);
		obj.setPfmobile("7722005480");
		Thread.sleep(1000);
		obj.setPfpersons("3");	
		Thread.sleep(1000);
		obj.setPfbuild("buv & 100");
		Thread.sleep(1000);
		obj.setPfarea("mno");
		Thread.sleep(1000);
	    obj.setPfcity("Select City");
	    Thread.sleep(1000);
		obj.setPfbutton();
	}

	@When("^user doesnot select state$")
	public void user_doesnot_select_state() throws Throwable {
		obj.setPffname("abc");	
		Thread.sleep(1000);
		obj.setPflname("qwer");	
		Thread.sleep(1000);
		obj.setPfemail("Capg1@gamil.com");
		Thread.sleep(1000);
		obj.setPfmobile("7722005480");
		Thread.sleep(1000);
		obj.setPfpersons("3");	
		Thread.sleep(1000);
		obj.setPfbuild("buv & 100");
		Thread.sleep(1000);
		obj.setPfarea("mno");
		Thread.sleep(1000);
	    obj.setPfcity("Pune");
	    Thread.sleep(1000);
 	    obj.setPfstate("Select State");
 	    Thread.sleep(1000);
 	   obj.setPfbutton();
	}

	@When("^user doesnot select conference full-access membership$")
	public void user_doesnot_select_conference_full_access_membership() throws Throwable {
		obj.setPffname("abc");	
		Thread.sleep(1000);
		obj.setPflname("qwer");	
		Thread.sleep(1000);
		obj.setPfemail("Capg1@gamil.com");
		Thread.sleep(1000);
		obj.setPfmobile("7722005480");
		Thread.sleep(1000);
		obj.setPfpersons("3");	
		Thread.sleep(1000);
		obj.setPfbuild("buv & 100");
		Thread.sleep(1000);
		obj.setPfarea("mno");
		Thread.sleep(1000);
	    obj.setPfcity("Pune");
	    Thread.sleep(1000);
 	    obj.setPfstate("Maharashtra");
 	    Thread.sleep(1000);
// 	   driver.switchTo().alert().dismiss();
		obj.setMemberStatus("");
		Thread.sleep(1000);
		obj.getPfbutton();
		
	}


	@When("^user enters all valid data$")
	public void user_enters_all_valid_data() throws Throwable {
		obj.setPffname("abc");	
		Thread.sleep(1000);
		obj.setPflname("qwer");	
		Thread.sleep(1000);
		obj.setPfemail("Capg1@gamil.com");
		Thread.sleep(1000);
		obj.setPfmobile("7722005480");
		Thread.sleep(1000);
		obj.setPfpersons("3");	
		Thread.sleep(1000);
		obj.setPfbuild("buv & 100");
		Thread.sleep(1000);
		obj.setPfarea("mno");
		Thread.sleep(1000);
	    obj.setPfcity("Pune");
	    Thread.sleep(1000);
 	    obj.setPfstate("Maharashtra");
 	    Thread.sleep(1000);
 	   obj.setMemberStatus("member");
		Thread.sleep(1000);
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		obj.setPfbutton();
	}

	@Then("^navigate to PaymentDetails page$")
	public void navigate_to_PaymentDetails_page() throws Throwable {
		driver.navigate().to("file:///D:/Users/TANAGRAW/Desktop/taneesha/module%203/MPT_setB/PaymentDetails.html");
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		driver.close();
	}

}
