package webdriver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class ConferenceWebDriver {
 static WebDriver driver;
 
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","D:\\Users\\TANAGRAW\\Desktop\\taneesha\\module 3\\chromedriver_win32\\chromedriver.exe");
	    driver=new ChromeDriver();
	    driver.get("file:///D:/Users/TANAGRAW/Desktop/taneesha/module%203/MPT_setB/ConferenceRegistartion.html#");
	
	    String title=driver.getTitle();
		if(title.contentEquals("Conference Registartion")) 
		    System.out.println("****** Title Matched");
		else 
			System.out.println("****** Title NOT Matched");

		
		driver.findElement(By.name("txtFN")).sendKeys("abc");
	
		driver.findElement(By.id("txtLastName")).sendKeys("def");
		driver.findElement(By.name("Email")).sendKeys("abc@gmail.com");
		driver.findElement(By.name("Phone")).sendKeys("9999999999");
		driver.findElement(By.xpath("html/body/form/table/tbody/tr[5]/td[1]")).sendKeys("5");
		driver.findElement(By.name("Address")).sendKeys("hjik & 1000");
		driver.findElement(By.name("Address2")).sendKeys("djdhuh");
		Select dropCity= new Select(driver.findElement(By.name("City")));
		dropCity.selectByIndex(1);
		
		Select dropState= new Select(driver.findElement(By.name("State")));
		dropState.selectByIndex(1);
		
		driver.findElement(By.name("memberStatus")).click();
		driver.findElement(By.xpath("html/body/form/table/tbody/tr[14]/td/a")).click();
	
	}

}
