package webdriver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class PaymentWebDriver {
	static WebDriver driver;
	public static void main(String[] args) 
	{
		
		System.setProperty("webdriver.chrome.driver","D:\\Users\\TANAGRAW\\Desktop\\taneesha\\module 3\\chromedriver_win32\\chromedriver.exe");
	    driver=new ChromeDriver();
	    driver.get("file:///D:/Users/TANAGRAW/Desktop/taneesha/module%203/MPT_setB/PaymentDetails.html");
	
	    String title=driver.getTitle();
		if(title.contentEquals("Payment Details")) 
		    System.out.println("****** Title Matched");
		else 
			System.out.println("****** Title NOT Matched");
	
		
		driver.findElement(By.id("txtCardholderName")).sendKeys("abc");
		driver.findElement(By.id("txtDebit")).sendKeys("123456789");
		driver.findElement(By.name("cvv")).sendKeys("123");
		driver.findElement(By.id("txtMonth")).sendKeys("10");
		driver.findElement(By.id("txtYear")).sendKeys("2019");
		driver.findElement(By.id("btnPayment")).click();
		
		/*String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
	    System.out.println("******" + alertMessage);
	    driver.close();*/
	}
}
