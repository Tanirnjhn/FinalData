package com.cg.beans;



import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.util.SocketUtils;

public class Client {

	public static void main(String[] args) {
	 Resource res= new ClassPathResource("beans.xml");
	 XmlBeanFactory factory=new  XmlBeanFactory(res);
	 Employee emp=(Employee) factory.getBean("e1");
	 Employee emp1=(Employee) factory.getBean("e2");
	 
	System.out.println(emp);
	System.out.println(emp1);
	}

}
