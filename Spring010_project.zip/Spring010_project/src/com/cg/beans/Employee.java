package com.cg.beans;

import java.util.ArrayList;

public class Employee {
    String firstName;
    String lastName;
    int age;
    Department dept;
   
    
	
	public Department getDept() {
		return dept;
	}
	public void setDept(Department dept) {
		this.dept = dept;
	}

	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Employee(String firstName, String lastName, int age, Department dept) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.age = age;
		this.dept = dept;
	}
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	@Override
	public String toString() {
		return "Employee [firstName=" + firstName + ", lastName=" + lastName + ", age=" + age + ", dept=" + dept + "]";
	}
	public Employee(String name,int age)
	{
		firstName=name.substring(0,name.indexOf(" ")-1);
		lastName=name.substring(0,name.indexOf(" ")+1);
	this.age=age;
	}
    public void m1() {
    	System.out.println("do some Initialization work here....");
    	
    }
     
    public void m2()
    {
    	System.out.println("clean up of bean.....");
    }
}
