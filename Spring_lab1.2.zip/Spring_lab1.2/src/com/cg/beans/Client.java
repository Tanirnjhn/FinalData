package com.cg.beans;

import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class Client {

	public static void main(String[] args) {
		
			Resource res= new ClassPathResource("beans.xml");
			 XmlBeanFactory factory=new  XmlBeanFactory(res);
			 Employee emp=(Employee) factory.getBean("e1");
			 System.out.println("Employee Details");
			 System.out.println("-------------------------------");
			System.out.println(emp);
			
		}

}
