package com.cg.beans;

public class Employee {
	private int empId;
	private String empName;
	private double salary;
	private SBU bU;
	private int age;
	
	
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public SBU getbU() {
		return bU;
	}
	public void setbU(SBU bU) {
		this.bU = bU;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", salary=" + salary + ", bU=" + bU + ", age="
				+ age + "]";
	}
	
	
}
