package com.cg.parallelproject.main;

import java.math.BigDecimal;
import java.util.Scanner;


import com.cg.parallelproject.beans.Customer;
import com.cg.parallelproject.beans.Wallet;
import com.cg.parallelproject.exception.InvalidAmountPresentException;
import com.cg.parallelproject.exception.InvalidPhoneNumberException;
import com.cg.parallelproject.exception.MobileNumberAlreadyExistException;
import com.cg.parallelproject.repo.CustomerRepo;
import com.cg.parallelproject.repo.CustomerRepoImpl;
import com.cg.parallelproject.service.CustomerService;
import com.cg.parallelproject.service.CustomerServiceImpl;

public class Main {

	public static void main(String[] args) throws InvalidPhoneNumberException, MobileNumberAlreadyExistException {

		CustomerRepo custRepo=new CustomerRepoImpl();
		CustomerService custSer=new CustomerServiceImpl(custRepo);		
		 custSer.createAccount("9198268281", "sarita", new BigDecimal("10000.09"));
		 custSer.createAccount("7500725707", "shivi", new BigDecimal("50000.0"));
		 custSer.depositAmount( "9198268281", new BigDecimal("1000"));
  /*
		CustomerRepo custRepo=new CustomerRepoImpl();
		CustomerService custSer=new CustomerServiceImpl(custRepo);
		
		Scanner scanner=new Scanner(System.in);
		
		System.out.println("1.Create Account");
		System.out.println("2.Show Balance");
		System.out.println("3.Deposit Amount");
		System.out.println("4.Withdraw Amount");
		System.out.println("5.Fund Transfer");
		System.out.println("6.Exit");
		
		while(true)
		{  System.out.println("Enter your choice");
			int choice=scanner.nextInt();
		
		  
		  switch(choice)
		  {
		  case 1: System.out.println("Enter the name of customer");
		  String cn=scanner.next();
		  Customer customer=new Customer();
		  customer.setName(cn);
		  
		  System.out.println("Enetr the mobile no of customer");
		  String mc=scanner.next();
		  customer.setMobileNo(mc);
		  
		  System.out.println("Enter balance of customer");
		  BigDecimal bal=scanner.nextBigDecimal();
		  Wallet wallet=new Wallet();
		  wallet.setBalance(bal);
		  customer.setWallet(wallet);
		 
		 System.out.println(customer.getName()+"\n"+customer.getMobileNo()+"\n"+customer.getWallet().getBalance());
		 break;
		 
		  case 2: System.out.println("Enter Mobile no");
		  String mobC=scanner.next();
		  Customer custom=custSer.showBalance(mobC);
		  System.out.println(custom);
		  break;
		  
		  case 3: System.out.println("Enter Mobile no");
		  String mNo=scanner.next();
		  Customer cust=new Customer();
		  cust.setMobileNo(mNo);
		  System.out.println("Enter amount");
		  BigDecimal Amt=scanner.nextBigDecimal();
		  Wallet wall=new Wallet();
		  wall.setBalance(Amt);
		  cust.setWallet(wall);
		  
		  System.out.println(cust.getMobileNo()+"\n"+cust.getWallet().getBalance());
		  break;
		  
		  case 4:System.out.println("Enter Mobile no");
		  String mobNo=scanner.next();
		  Customer custm=new Customer();
		  custm.setMobileNo(mobNo);
		  System.out.println("Enter amount");
		  BigDecimal Amnt=scanner.nextBigDecimal();
		  Wallet wallt=new Wallet();
		  wallt.setBalance(Amnt);
		  custm.setWallet(wallt);
		  
		  System.out.println(custm.getMobileNo()+"\n"+custm.getWallet().getBalance());
		  break;
		  
		  case 5: System.out.println("Enter source mob number");
		   String sourceMobNo=scanner.next();
		   Customer cusm=new Customer();
		   cusm.setMobileNo(sourceMobNo);
		   System.out.println("enter Target Mob No");
		   String targetmobNo=scanner.next();
		   cusm.setMobileNo(targetmobNo);
		   System.out.println("Enter Amount");
		   BigDecimal amount=scanner.nextBigDecimal();
		   Wallet wal=new Wallet();
		   wal.setBalance(amount);
		   cusm.setWallet(wal);
		  
		   System.out.println(cusm.getMobileNo()+"\n" +cusm.getMobileNo()+"\n"+ cusm.getWallet().getBalance());
		 
		  break;
		  
		  case 6: System.exit(0);
		  }
		  
		  
		  
		}
*/
	}

}
