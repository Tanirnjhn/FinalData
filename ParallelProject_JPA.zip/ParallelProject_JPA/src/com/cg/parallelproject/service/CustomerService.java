package com.cg.parallelproject.service;

import java.math.BigDecimal;


import com.cg.parallelproject.beans.Customer;
import com.cg.parallelproject.exception.InvalidAmountPresentException;
import com.cg.parallelproject.exception.InvalidPhoneNumberException;
import com.cg.parallelproject.exception.MobileNumberAlreadyExistException;



public interface CustomerService {
	public Customer createAccount(String mobileNo, String name, BigDecimal initialBalance)throws MobileNumberAlreadyExistException;
	public Customer showBalance(String mobileNo) throws  InvalidPhoneNumberException;
    public Customer depositAmount(String mobileNo,BigDecimal Amount)throws  InvalidPhoneNumberException;
    public Customer withdrawAmount(String mobileNo,BigDecimal Amount)throws InvalidAmountPresentException, InvalidPhoneNumberException;
   public boolean validAmount(BigDecimal Amount)throws InvalidAmountPresentException ;
    public Customer fundTransfer(String sourceMobNo,String Target,BigDecimal Amount);
	boolean repeatedAcc(String mobileNo);
}
