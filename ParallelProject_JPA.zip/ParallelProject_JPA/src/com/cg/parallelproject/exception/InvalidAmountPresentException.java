package com.cg.parallelproject.exception;

public class InvalidAmountPresentException extends Exception {

}
