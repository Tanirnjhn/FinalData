package com.cg.parallelproject.exception;

public class InvalidPhoneNumberException extends Exception {

}
