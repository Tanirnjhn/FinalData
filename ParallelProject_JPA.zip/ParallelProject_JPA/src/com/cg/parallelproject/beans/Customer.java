package com.cg.parallelproject.beans;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="custm_table")
public class Customer {
@Id

private String mobileNo;

private String name;
@Embedded
private Wallet wallet;
public String getMobileNo() {
	return mobileNo;
}
public void setMobileNo(String mobileNo) {
	this.mobileNo = mobileNo;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public Wallet getWallet() {
	return wallet;
}
public void setWallet(Wallet wallet) {
	this.wallet = wallet;
}
@Override
public String toString() {
	return "Customer [mobileNo=" + mobileNo + ", name=" + name + ", wallet=" + wallet + "]";
}



}
