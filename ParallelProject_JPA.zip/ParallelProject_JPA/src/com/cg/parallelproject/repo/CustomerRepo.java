package com.cg.parallelproject.repo;

import java.math.BigDecimal;

import com.cg.parallelproject.beans.Customer;

public interface CustomerRepo {

	public boolean save(Customer customer);
	public Customer findByOne(String mobileNo) ;
	public boolean update(String mobileNo,BigDecimal balance);
	
}
