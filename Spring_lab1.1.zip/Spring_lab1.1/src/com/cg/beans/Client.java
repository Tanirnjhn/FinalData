package com.cg.beans;

import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Resource res= new ClassPathResource("beans.xml");
		 XmlBeanFactory factory=new  XmlBeanFactory(res);
		 Employee emp=(Employee) factory.getBean("emp");
		 System.out.println("Employee Details");
		 System.out.println("--------------------------------------------------------");
		 System.out.println("Employee ID:"+emp.getEmpId());
		 System.out.println("Employee Name:"+emp.getEmpName());
		 System.out.println("Employee Salary:"+emp.getSalary());
		 System.out.println("Employee BU:"+emp.getbU());
		 System.out.println("Employee Age:"+emp.getAge());
	}

}
