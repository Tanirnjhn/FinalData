package com.cg.bean;

import java.beans.PropertyEditorSupport;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import javax.print.attribute.standard.DateTimeAtCompleted;

public class DateEditor extends PropertyEditorSupport{
@Override
public void setAsText(String xmlDate ) throws IllegalArgumentException{
	//arg0 will contain the date in string format
	//below logic will convert the string to LocalDate
	
	DateTimeFormatter formatter=DateTimeFormatter.ofPattern("dd-MM-yyyy");
	LocalDate dt=LocalDate.parse(xmlDate, formatter);
	setValue(dt);  // this will det date to join date property
}
}
