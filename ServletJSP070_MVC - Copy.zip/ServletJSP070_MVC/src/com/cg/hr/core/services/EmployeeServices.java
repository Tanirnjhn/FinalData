package com.cg.hr.core.services;

import java.util.ArrayList;

import com.cg.hr.core.beans.Employee;
import com.cg.hr.core.exception.EmpException;

public interface EmployeeServices {
	 ArrayList<Employee> fetchAllEmp() throws EmpException;
	 public Employee getEmpByEId(int empId) throws EmpException;
}
