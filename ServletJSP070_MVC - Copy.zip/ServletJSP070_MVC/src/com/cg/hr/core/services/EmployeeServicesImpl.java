package com.cg.hr.core.services;

import java.util.ArrayList;

import com.cg.hr.core.beans.Employee;
import com.cg.hr.core.daos.EmployeeDao;
import com.cg.hr.core.daos.EmployeeDaoImpl;
import com.cg.hr.core.exception.EmpException;

public class EmployeeServicesImpl implements EmployeeServices{
 private EmployeeDao dao;
 
	public EmployeeServicesImpl() throws EmpException {
	dao=new EmployeeDaoImpl();
}

	@Override
	public ArrayList<Employee> fetchAllEmp() throws EmpException {
		
		return dao.fetchAllEmp();
	}

	@Override
	public Employee getEmpByEId(int empId) throws EmpException {
		
		return dao.getEmpByEId(empId);
	}

}
