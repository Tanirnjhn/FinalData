package com.cg.hr.core.listener;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebListener;

import com.cg.hr.core.exception.EmpException;
import com.cg.hr.core.services.EmployeeServices;
import com.cg.hr.core.services.EmployeeServicesImpl;


@WebListener
public class CreateServiceResources implements ServletContextListener {
 private EmployeeServices services;
    
 
 

    public void contextDestroyed(ServletContextEvent arg0)  { 
       services=null;
    }
    public void contextInitialized(ServletContextEvent arg0)  { 
         try {
			services= new EmployeeServicesImpl();
			 ServletContext ctx=arg0.getServletContext();
			 ctx.setAttribute("services", services);
		} catch (EmpException e) {
			try {
				throw new ServletException("Missed Service Reference",e);
			}catch(ServletException e1) {
			e.printStackTrace();
		}
    }
	
}
}