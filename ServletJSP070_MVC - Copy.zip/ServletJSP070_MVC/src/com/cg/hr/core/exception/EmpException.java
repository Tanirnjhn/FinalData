package com.cg.hr.core.exception;

public class EmpException extends Exception {

	public EmpException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	
	}

	public EmpException(String arg0) {
		super(arg0);
		
	}

}
