package com.cg.hr.core.daos;

import java.util.ArrayList;

import com.cg.hr.core.beans.Employee;
import com.cg.hr.core.exception.EmpException;

public interface EmployeeDao {
	 ArrayList<Employee> fetchAllEmp() throws EmpException;
	 public Employee getEmpByEId(int empId) throws EmpException;
}
