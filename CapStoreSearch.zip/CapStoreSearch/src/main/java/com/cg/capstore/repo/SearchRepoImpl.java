package com.cg.capstore.repo;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.capstore.beans.Coupon;
import com.cg.capstore.beans.Product;

@Repository()
public class SearchRepoImpl implements SearchRepo {
	@PersistenceContext
	EntityManager entityManager;

	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	List<Coupon> a = new ArrayList<>();



	@Override
	public List<Product> viewProducts() {
		TypedQuery<Product> query=
				entityManager.createQuery
				("select product from Product product ", Product.class);
						
					List<Product> list= query.getResultList();
				return list;
	}
	
	
	@Override
	public Product findProduct(String name) {
		Product product= 
				entityManager.find(Product.class, name);
		if(product==null)
			return null;
		product.setName(name);
		return product;
	}

	

}
