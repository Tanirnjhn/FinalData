package com.cg.capstore.service;

import java.util.List;

import com.cg.capstore.beans.Product;

public interface SearchService {
	
	public List<Product> viewProducts();
	public Product findProduct(String name);

}
