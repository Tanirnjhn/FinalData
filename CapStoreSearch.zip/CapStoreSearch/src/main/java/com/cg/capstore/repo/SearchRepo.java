package com.cg.capstore.repo;

import java.util.List;

import com.cg.capstore.beans.Product;

public interface SearchRepo {

	public List<Product> viewProducts();
	public Product findProduct(String name);

	
}
