package com.cg.capstore.CapStoreSearch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.cg")
@EntityScan("com.cg.capstore.beans")
public class CapStoreSearchApplication {

	public static void main(String[] args) {
		SpringApplication.run(CapStoreSearchApplication.class, args);
	}

}

