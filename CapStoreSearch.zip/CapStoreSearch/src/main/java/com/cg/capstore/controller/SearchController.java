package com.cg.capstore.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.capstore.beans.Product;
import com.cg.capstore.service.SearchService;



@RestController
public class SearchController {
	@Autowired
	SearchService service;
	
	
	@RequestMapping(value="viewProducts",produces="application/json")
	public List<Product> getProductList()
	{
		List<Product> list =service.viewProducts();
		return list;
	}
	
	
	@RequestMapping(value="/findProduct/{name}",produces="application/json")
	public Product findProduct(@PathVariable String name)
	{
		Product product=service.findProduct(name);
		return product;
	}
	
}
	
	
	
	
	
	
	
	
	
	
	
	

