package com.cg.capstore.repository;

import com.cg.capstore.beans.Product;

public interface DiscountRepo {
Product applyDiscount(int prodId);
}
