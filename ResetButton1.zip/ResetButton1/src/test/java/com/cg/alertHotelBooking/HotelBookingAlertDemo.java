package com.cg.alertHotelBooking;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class HotelBookingAlertDemo {
	static WebDriver driver;
	public static void main(String[] args) throws InterruptedException{
		System.setProperty("webdriver.chrome.driver","D:\\Users\\TANAGRAW\\Desktop\\taneesha\\module 3\\chromedriver_win32\\chromedriver.exe");
		driver= new ChromeDriver();
		driver.get("file:///D:/Users/TANAGRAW/Desktop/taneesha/module%203/hotelbooking.html");
		
		
		/************For Blank FirstName************/
		driver.findElement(By.id("txtFirstName")).sendKeys("");
//		driver.findElement(By.id("btnPayment")).click();
//		callAlert();
//		
		/************For FirstName************/
		driver.findElement(By.id("txtFirstName")).sendKeys("Taneesha");

		/************For blank LastName************/
		driver.findElement(By.id("txtLastName")).sendKeys("");
//		driver.findElement(By.id("btnPayment")).click();
//		callAlert();
		
		/************For LastName************/
    	driver.findElement(By.id("txtLastName")).sendKeys("Agrawal");
		
		/************For blank email***************/
		driver.findElement(By.id("txtEmail")).sendKeys("");
//    	driver.findElement(By.id("btnPayment")).click();
//		callAlert();
		
		/************For  email***************/
		driver.findElement(By.id("txtEmail")).sendKeys("taniagrawal56@gmail.com");
    	
		
		/************ For invalid Mobile No************/
//		driver.findElement(By.xpath(".//*[@id='txtPhone']")).sendKeys("7830447679");;
	    driver.findElement(By.cssSelector("input[pattern='[789][0-9]{9}']")).sendKeys("7896");	
	    driver.findElement(By.id("btnPayment")).click();
     	callAlert();
	    
     	/************ For valid Mobile No************/
		driver.findElement(By.cssSelector("input[pattern='[789][0-9]{9}']")).clear();	
	    driver.findElement(By.cssSelector("input[pattern='[789][0-9]{9}']")).sendKeys("7830447679");	
	    
	   /*********** For Address*********/
		driver.findElement(By.xpath("html/body/div/div/form/table/tbody/tr[6]/td[2]/textarea")).sendKeys("Agrawal Market");
		
		/***********For blank city**************/
		Select drpCity= new Select(driver.findElement(By.name("city")));
		drpCity.selectByVisibleText("Select City");
//		driver.findElement(By.id("btnPayment")).click();
//		callAlert();
		
		/************** For City**************/
		Select dropCity= new Select(driver.findElement(By.name("city")));
		dropCity.selectByVisibleText("Pune");
		
		/**************  For blank State  ******************/
		Select drpCity1= new Select(driver.findElement(By.name("state")));
		drpCity1.selectByVisibleText("Select State");
//		driver.findElement(By.id("btnPayment")).click();
//		callAlert();
		
		/***************For State**************/
		Select dropCity1= new Select(driver.findElement(By.name("state")));
		dropCity1.selectByVisibleText("Tamilnadu");
	
		/************************ For Person********************/
		Select drpCity2= new Select(driver.findElement(By.name("persons")));
		drpCity2.selectByVisibleText("3");

		/**********************For Blank Card Holder NAme*****************/
		driver.findElement(By.id("txtCardholderName")).sendKeys("");
//		driver.findElement(By.id("btnPayment")).click();
//		callAlert();
		
		/**********************For Card Holder Name*****************/
		driver.findElement(By.id("txtCardholderName")).sendKeys("TaneeshaAgrawal");

		/**********************For Blank Debit Card Number*****************/
		driver.findElement(By.id("txtDebit")).sendKeys("");
//		driver.findElement(By.id("btnPayment")).click();
//		callAlert();
		
		/**********************For Debit Card Number*****************/
		driver.findElement(By.id("txtDebit")).sendKeys("7054685194");
		
		/***************For blank CVV*************/
		driver.findElement(By.id("txtCvv")).sendKeys("");
//		driver.findElement(By.id("btnPayment")).click();
//		callAlert();
		
		/***************For  CVV*************/
		driver.findElement(By.id("txtCvv")).sendKeys("871");
		
		/***************For blank Expiration Month*************/
		driver.findElement(By.id("txtMonth")).sendKeys("");
//		driver.findElement(By.id("btnPayment")).click();
//		callAlert();
		

		/***************For blank Expiration Month*************/
		driver.findElement(By.id("txtMonth")).sendKeys("07");
		
		
		/***************For blank Expiration YEAR*************/
		driver.findElement(By.id("txtYear")).sendKeys("");
//		driver.findElement(By.id("btnPayment")).click();
//		callAlert();
	

		/***************For blank Expiration YEAR*************/
		driver.findElement(By.id("txtYear")).sendKeys("23");
		driver.findElement(By.id("btnPayment")).click();
	}

	public static void callAlert() {
		
		Alert alert= driver.switchTo().alert();
		System.out.println("the message is:"+alert.getText());
		alert.accept();
	}
}
