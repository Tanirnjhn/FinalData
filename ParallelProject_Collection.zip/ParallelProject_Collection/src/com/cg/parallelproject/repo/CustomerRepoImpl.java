package com.cg.parallelproject.repo;

import com.cg.parallelproject.beans.Customer;
import com.cg.parallelproject.exception.InvalidMobileNumberException;

public class CustomerRepoImpl implements CustomerRepo{

	@Override
	public boolean save(Customer customer) {
	
		return false;
	}

	@Override
	public Customer findOne(String mobileNo) throws InvalidMobileNumberException {
	
		return null;
	}

}
