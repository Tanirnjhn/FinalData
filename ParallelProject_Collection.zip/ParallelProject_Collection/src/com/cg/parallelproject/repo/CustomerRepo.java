package com.cg.parallelproject.repo;

import com.cg.parallelproject.beans.Customer;
import com.cg.parallelproject.exception.InvalidMobileNumberException;

public interface CustomerRepo {

	public boolean save(Customer customer);
	public Customer findOne(String mobileNo) throws InvalidMobileNumberException;
}
