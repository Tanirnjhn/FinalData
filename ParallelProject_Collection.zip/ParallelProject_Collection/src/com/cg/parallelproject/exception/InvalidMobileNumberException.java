package com.cg.parallelproject.exception;

public class InvalidMobileNumberException extends Exception {

}
