package Hotel_Booking;


@RunWith(Cucumber.class)
@CucumberOptions(plugin= {"pretty"})
public class RunTestHotelBooking {

}
