package com.cg.hr;

import java.io.IOException;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
/*  Life Cycle methods.
 * init(ServletConfig): its for initialization.
 *         Initialization, Resources allocation are done here.
 *     init():its for initialization and use while overriding.
 * service():  this method is called on every request.
 *            Controlling, Transformation
 * Destroy(): this method is called while un-deploying the servlet.
 *            Resource Deallocation. 
 *      Eager:Created at the time of starting the server. Consumes Memory
 *      resources right from beginning.
 *      Normally used for the servlet which are always used by all users.
 *      load on Startup is positive.
 *      Home,Login, MainMenu
 *      Lazy:Created only when first request comes in.
 *     Normally used for servlets which may be instantiated optionally.
 *     ListAllEmps,AddnewEmps       
 
 *   Servlet API
 */

@WebServlet(urlPatterns="/MyServlet",loadOnStartup=2)
public class MyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	public void init() throws ServletException { //init is Life cycle parameter
		
		System.out.println("In init(ServletConfig)");
	}

	
	public void destroy() {
		System.out.println("In destroy()");
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		System.out.println("In doGet()");
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		 doGet(request, response);
	}

}
