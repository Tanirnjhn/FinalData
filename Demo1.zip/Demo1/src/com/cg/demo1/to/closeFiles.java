package com.cg.demo1.to;

import java.io.File;
import java.io.IOException;

public class closeFiles{
	public void closeFile() {
		
		try{
		fromFile.close();
		toFile.close();
		} catch (IOException ioe){
		System.out.println("Exception: " + ioe);
		}
		}
		public static void main(String[] args){
		CopyFile c1 = new CopyFile();
		c1.init(args[0], args[1]);
		c1.copyContents();
		c1.closeFiles();
		} }

